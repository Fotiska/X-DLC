(async () => {
    class FMod {
        constructor() {
            this.id = -1;
            this.name = 'Unknown';
            this.author = 'Unknown';
            this.description = 'Unknown';
            this.arrows = {};
        }
    }
    class FModArrow {
        constructor() {
            this.id = 25;
            this.name = [];
            this.info = [];
            this.does = [];
            this.mod = null;
            this.icon_url = "";
            this.is_pressable = false;
            this.custom_data = 0;

            this.update = (arrow) => arrow.signal = 0;
            this.press = (arrow) => undefined;
            this.transmit = (arrow) => undefined;
            this.block = (arrow) => undefined;
        }
    }
    class SignalUpdater {
        /**
         * @param {FAPI} FAPI
         */
        constructor(FAPI) {
            this.FAPI = FAPI;
        }
        /**
         * Перенос текущих значений стрелочки в старые
         * @param {Object.<string,any>} arrow Стрелочка
         */
        toLast = function(arrow) {
            arrow.lastType = arrow.type;
            arrow.lastSignal = arrow.signal;
            arrow.lastRotation = arrow.rotation;
            arrow.lastFlipped = arrow.flipped;
        }
        /**
         * Добавляет единицу к количеству сигналов полученной стрелочки
         * @param {Object.<string,any> | void} arrow Стрелочка
         */
        updateCount = function(arrow) {
            if (arrow !== undefined) arrow.signalsCount += 1;
        }
        /**
         * Блокирует сигнал полученной стрелочки
         * <br><b>Вызывать не в `transmit` а в `block` иначе не будет никакого эффекта!</b>
         * @param {Object.<string,any> | void} arrow Стрелочка
         */
        blockSignal = function(arrow) {
            if (arrow !== undefined) arrow.signal = 0;
        }
        /**
         * Сложный вариант получения стрелочки
         * @param {Object.<string,any>} chunk - Чанк
         * @param {number} x Позиция по X
         * @param {number} y Позиция по Y
         * @param {number} rotation Поворот стрелочки ( 0 вверх | 1 вправо | 2 вниз | 3 влево )
         * @param {boolean} flipped Зеркально расположена или нет
         * @param {number} distance Дистанция от стрелочки ( отрицательное = вперёд | положительное = назад )
         * @param {number} diagonal Дистанция от стрелочки в сторону ( отрицательное = вправо | положительное = влево )
         * @return {Object.<string,any> | void} Возвращает стрелочку если находит её, а иначе `null`
         */
        adv_getArrowAt = function(chunk, x, y, rotation, flipped, distance=-1, diagonal=0) {
            if (flipped) diagonal = -diagonal;

            if (rotation === 0) {
                y += distance;
                x += diagonal;
            }
            else if (rotation === 1) {
                y += diagonal;
                x -= distance;
            }
            else if (rotation === 2) {
                y -= distance;
                x -= diagonal;
            }
            else if (rotation === 3) {
                y -= diagonal;
                x += distance;
            }

            let l = chunk;
            if (x >= this.FAPI.CHUNK_SIZE) {
                if (y >= this.FAPI.CHUNK_SIZE) {
                    l = chunk.adjacentChunks[3];
                    x -= this.FAPI.CHUNK_SIZE;
                    y -= this.FAPI.CHUNK_SIZE;
                }
                else if (y < 0) {
                    l = chunk.adjacentChunks[1];
                    x -= this.FAPI.CHUNK_SIZE;
                    y += this.FAPI.CHUNK_SIZE;
                }
                else {
                    l = chunk.adjacentChunks[2];
                    x -= this.FAPI.CHUNK_SIZE;
                }
            }
            else if (x < 0) {
                if (y < 0) {
                    l = chunk.adjacentChunks[7];
                    x += this.FAPI.CHUNK_SIZE;
                    y += this.FAPI.CHUNK_SIZE;
                } else if (y >= this.FAPI.CHUNK_SIZE) {
                    l = chunk.adjacentChunks[5];
                    x += this.FAPI.CHUNK_SIZE;
                    y -= this.FAPI.CHUNK_SIZE;
                } else {
                    l = chunk.adjacentChunks[6];
                    x += this.FAPI.CHUNK_SIZE;
                }
            }
            else if (y < 0) {
                l = chunk.adjacentChunks[0];
                y += this.FAPI.CHUNK_SIZE;
            }
            else if (y >= this.FAPI.CHUNK_SIZE) {
                l = chunk.adjacentChunks[4];
                y -= this.FAPI.CHUNK_SIZE;
            }
            if (l !== undefined) return l.getArrow(x, y);
        }
        // /**
        //  * Упрощённый вариант получения стрелочки
        //  * @param {Object.<string,any>} arrow Стрелочка
        //  * @param {number} distance Дистанция от стрелочки ( отрицательное = вперёд | положительное = назад )
        //  * @param {number} diagonal Дистанция от стрелочки в сторону ( отрицательное = вправо | положительное = влево )
        //  * @return {Object.<string,any> | void} Возвращает стрелочку если находит её, а иначе `null`
        //  */
        // getArrowAt(arrow, distance=-1, diagonal=0) {
        //
        // }
        /**
         * Обновление сигналов стрелочек
         * @param {Object.<string,any>} gameMap Карта
         * @return {void} Ничего не возвращает
         */
        update = function(gameMap) {
            gameMap.chunks.forEach((chunk) => {
                for (let x = 0; x < this.FAPI.CHUNK_SIZE; x++) {
                    for (let y = 0; y < this.FAPI.CHUNK_SIZE; y++) {
                        const arrow = chunk.getArrow(x, y);
                        this.toLast(arrow);
                        switch (arrow.type) {
                            case 0:
                                break;
                            case 1: // Стрелочка
                            case 4: // Стрелочка задержки
                            case 5: // Передатчик
                            case 22: // Стрелочка из уровня #1
                                if (arrow.signal === 1) this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped));
                                break;
                            case 2: // Источник
                            case 9: // Тактовый источник
                                if (arrow.signal === 1) {
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, -1));
                                }
                                break;
                            case 6: // <>
                                if (arrow.signal === 1) {
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 1, 0));
                                }
                                break;
                            case 7: // ^>
                                if (arrow.signal === 1) {
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                                }
                                break;
                            case 8: // <^>
                                if (arrow.signal === 1) {
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, -1));
                                }
                                break;
                            case 10: // Синяя стрелочка
                                if (arrow.signal === 2) this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -2))
                                break;
                            case 11: // Диагональная стрелочка
                                if (arrow.signal === 2) this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 1))
                                break;
                            case 12: // Синий курсор
                                if (arrow.signal === 2) {
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -2, 0));
                                }
                                break;
                            case 13: // Полусиний курсор
                                if (arrow.signal === 2) {
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -2, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                                }
                                break;
                            case 14: // Синий курсор ЛКМ
                                if (arrow.signal === 2) {
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 1));
                                }
                                break;
                            case 15: // НЕ
                            case 16: // И
                            case 17: // Хуйня какая та
                            case 18: // Ячейка памяти
                            case 19: // И + Ячейка памяти
                                if (arrow.signal === 3) this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped))
                                break;
                            case 20: // Рандомизатор
                            case 24: // Направленная кнопка
                                if (arrow.signal === 5) this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped));
                                break;
                            case 21: // Кнопка
                                if (arrow.signal === 5) {
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 1, 0));
                                    this.updateCount(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, -1));
                                }
                                break;
                            default:
                                let marrow = this.FAPI.getArrowByType(arrow.type);
                                if (marrow !== undefined) marrow.transmit(arrow, chunk, x, y);
                                break;
                        }
                    }
                }
            });
            gameMap.chunks.forEach((chunk) => {
                for (let x = 0; x < this.FAPI.CHUNK_SIZE; x++) {
                    for (let y = 0; y < this.FAPI.CHUNK_SIZE; y++) {
                        const arrow = chunk.getArrow(x, y);
                        switch (arrow.type) {
                            case 0:
                                break;
                            case 1:
                            case 3:
                            case 6:
                            case 7:
                            case 8:
                            case 23:
                                arrow.signal = arrow.signalsCount > 0 ? 1 : 0;
                                break;
                            case 2:
                                arrow.signal = 1;
                                break;
                            case 4:
                                if (arrow.signal === 2) arrow.signal = 1;
                                else if (arrow.signal === 0 && arrow.signalsCount > 0) arrow.signal = 2;
                                else if (arrow.signal === 1 && arrow.signalsCount > 0) arrow.signal = 1;
                                else arrow.signal = 0;
                                break;
                            case 5:
                                arrow.signal = 0;
                                const backward_arrow = this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 1);
                                if (backward_arrow !== undefined) arrow.signal = backward_arrow.lastSignal !== 0 ? 1 : 0;
                                break;
                            case 9:
                                if (arrow.signal === 0) arrow.signal = 1;
                                else if (arrow.signal === 1) arrow.signal = 2;
                                break;
                            case 10:
                            case 11:
                            case 12:
                            case 13:
                            case 14:
                                arrow.signal = arrow.signalsCount > 0 ? 2 : 0;
                                break;
                            case 15:
                                arrow.signal = arrow.signalsCount > 0 ? 0 : 3;
                                break;
                            case 16:
                                arrow.signal = arrow.signalsCount > 1 ? 3 : 0;
                                break;
                            case 17:
                                arrow.signal = arrow.signalsCount % 2 === 1 ? 3 : 0;
                                break;
                            case 18:
                                if (arrow.signalsCount > 1) arrow.signal = 3;
                                else if (arrow.signalsCount === 1) arrow.signal = 0;
                                break;
                            case 19:
                                if (arrow.signalsCount > 0) arrow.signal = arrow.signal === 3 ? 0 : 3;
                                break;
                            case 20:
                                arrow.signal = (arrow.signalsCount > 0 && Math.random() < 0.5) ? 5 : 0;
                                break;
                            case 21:
                                arrow.signal = 0;
                                break;
                            case 22:
                                arrow.signal = arrow.signalsCount > 0 ? 1 : 0;
                                const n = chunk.getLevelArrow(x, y);
                                if (n !== null) n.update();
                                break;
                            case 24:
                                arrow.signal = arrow.signalsCount > 0 ? 5 : 0;
                                break;
                            default:
                                let marrow = this.FAPI.getArrowByType(arrow.type);
                                if (marrow !== undefined) marrow.update(arrow);
                                break;
                        }
                        arrow.signalsCount = 0;
                    }
                }
            });
            gameMap.chunks.forEach((chunk) => {
                for (let x = 0; x < this.FAPI.CHUNK_SIZE; x++) {
                    for (let y = 0; y < this.FAPI.CHUNK_SIZE; y++) {
                        const arrow = chunk.getArrow(x, y);
                        if (arrow.type === 3 && arrow.lastSignal === 1)
                            this.blockSignal(this.adv_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped));
                        else if (arrow.type > 24) {
                            let marrow = this.FAPI.getArrowByType(arrow.type);
                            if (marrow !== undefined) marrow.block(arrow, chunk, x, y);
                        }
                    }
                }
            });
            gameMap.chunks.forEach((chunk) => {
                for (let x = 0; x < this.FAPI.CHUNK_SIZE; x++) {
                    for (let y = 0; y < this.FAPI.CHUNK_SIZE; y++) {
                        const arrow = chunk.getArrow(x, y);
                        if (arrow.type === 23) chunk.update();
                    }
                }
            });
        }
    }
    class AtlasModifier {
        constructor() {
            this.arrowsToAdd = [];
            this.isAtlasModifying = false;
        }
        appendArrow(index, texture) {
            this.arrowsToAdd.push([index, texture]);
            console.log(`Arrow with id \`${index}\` registered`)
            if (!this.isAtlasModifying) {
                console.log('Atlas is being to be modified')
                this.startAtlasModifying();
            }
        }
        startAtlasModifying() {
            let atlasModifier = this;
            function repeat() {
                if (atlasModifier.arrowsToAdd.length === 0) {
                    game.PlayerSettings.arrowAtlasImage.onload = () => game.navigation.gamePage.game.render.createArrowTexture(game.PlayerSettings.arrowAtlasImage);
                    atlasModifier.isAtlasModifying = false;
                    return;
                }
                let pair = atlasModifier.arrowsToAdd.pop(0);
                let index = pair[0];
                let src = pair[1];

                let x = (index - 1) % 8;
                let y = ~~(index / 8);
                const img1 = new Image();
                const img2 = new Image();
                img1.src = game.PlayerSettings.arrowAtlasImage.src;
                img2.src = src;
                img2.onload = function() {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');

                    canvas.width = img1.width;
                    canvas.height = img1.height;

                    ctx.drawImage(img1, 0, 0);
                    ctx.drawImage(img2, x * 256, y * 256);

                    game.PlayerSettings.arrowAtlasImage = new Image;
                    game.PlayerSettings.arrowAtlasImage.src = canvas.toDataURL('image/png');
                    repeat()
                };
            }
            this.isAtlasModifying = true;
            repeat();
        }
    }
    class DataHandler {
        constructor(FAPI) {
            this.FAPI = FAPI;
            let dataHandler = this;
            game.save.__proto__.save = dataHandler.save;
        }

        save(gameMap) {
            const data = [];
            data.push(0, 0);
            data.push(255 & gameMap.chunks.size, gameMap.chunks.size >> 8 & 255);
            gameMap.chunks.forEach((chunk) => {
                const types = chunk.getArrowTypes();
                const x = [255 & Math.abs(chunk.x), Math.abs(chunk.x) >> 8 & 255];
                const y = [255 & Math.abs(chunk.y), Math.abs(chunk.y) >> 8 & 255];
                chunk.x < 0 ? x[1] |= 128 : x[1] &= 127;
                chunk.y < 0 ? y[1] |= 128 : y[1] &= 127;
                data.push(...x);
                data.push(...y);
                data.push(types.length - 1);
                types.forEach((arrowType) => {
                    data.push(arrowType);
                    data.push(0);
                    const n = data.length - 1;
                    let o = 0;
                    for (let x = 0; x < 16; x++) {
                        for (let y = 0; y < 16; y++) {
                            const arrow = chunk.getArrow(x, y);
                            if (arrow.type === arrowType) {
                                const e = n | y << 4;
                                const s = arrow.rotation | (arrow.flipped ? 1 : 0) << 2;
                                data.push(e);
                                data.push(s);
                                o++;
                            }
                        }
                    }
                    data[n] = o - 1;
                });
            })
            console.log(data);
            return data;
        }
    }
    class FAPI {
        constructor() {
            // closeAnyModal
            // openedAnyModal

            let fapi = this;
            this.img_sources = JSON.parse(sessionStorage.api_sources);
            this.CHUNK_SIZE = 16;
            this.CELL_SIZE = 250;
            this.MAX_TYPE = 24;
            this.SignalUpdater = new SignalUpdater(this);
            this.AtlasModifier = new AtlasModifier(this);
            this.DataHandler = new DataHandler(this);
            this.FModArrowType = FModArrow;
            this.mods = [];
            this.moddedArrows = {};
            this.modals = [];

            // region Overrides
            game.navigation.gamePage.playerUI.toolbarController.uiToolbar.items[0].__proto__.setImage = function(id) {
                if (id < 24) this.image.src = `res/sprites/arrow${id + 1}.png?v=${game.PlayerSettings.version}`;
                else {
                    let marrow = fapi.getArrowByType(id + 1);
                    if (marrow !== undefined) this.image.src = marrow.icon_url;
                }
            }
            game.ChunkUpdates.update = (gameMap) => {this.SignalUpdater.update(gameMap)};

            let prevControls = game.navigation.gamePage.playerControls.update;
            let prevLeftClickCallback = game.navigation.gamePage.playerControls.leftClickCallback;
            let prevKeyDownCallback = game.navigation.gamePage.playerControls.keyDownCallback;
            game.navigation.gamePage.playerControls.keyDownCallback = function(e, t) {
                if (e === "Escape" && fapi.closeAnyModal()) return;
                prevKeyDownCallback.apply(game.navigation.gamePage.playerControls, e, t);
            }
            game.navigation.gamePage.playerControls.leftClickCallback = function() {
                if (game.navigation.gamePage.playerControls.playerUI.isMenuOpen()) return;

                prevLeftClickCallback.apply(game.navigation.gamePage.playerControls);
                const arrow = game.navigation.gamePage.playerControls.getArrowByMousePosition();
                const shiftPressed = game.navigation.gamePage.playerControls.keyboardHandler.getShiftPressed();

                if (arrow !== undefined && game.navigation.gamePage.playerControls.freeCursor && !shiftPressed) {
                    // Потом сделать чтобы с зажатым шифтом открывались настройки всех выделенных стрелочек
                    if (arrow.type > 24) {
                        let marrow = fapi.getArrowByType(arrow.type);
                        if (marrow !== undefined) marrow.press(arrow);
                    }
                }
            }
            game.navigation.gamePage.playerControls.mouseHandler.leftClickCallback = game.navigation.gamePage.playerControls.leftClickCallback;
            game.navigation.gamePage.playerControls.update = function() {
                prevControls.apply(game.navigation.gamePage.playerControls);
                const arrow = game.navigation.gamePage.playerControls.getArrowByMousePosition();
                if (arrow !== undefined && arrow.type > 24) {
                    let marrow = fapi.getArrowByType(arrow.type);
                    if (marrow !== undefined) document.body.style.cursor = marrow.is_pressable ? 'pointer' : 'default';
                }
            }
            // endregion
        }

        /**
         * @param {number} type Айди стрелочки
         * @return {FModArrow} Стрелочку из мода
         */
        getArrowByType = function(type) {
            return this.moddedArrows[type];
        }
        /**
         * @param {number} id Айди мода
         * @return {FMod} Мод
         */
        getModById(id) {
            let mod;
            this.mods.forEach((fmod) => {
                if (fmod.id === id) mod = fmod;
            });
            return mod;
        }
        registerMod(name, author, description, on_registered) {
            let mod = new FMod();
            mod.id = this.mods.length;
            mod.name = name;
            mod.author = author;
            mod.description = description;
            this.mods.push(mod);
            console.log(`Mod ${name} registered`)
            on_registered(mod);
        }
        registerArrows(arrows, mod) {
            let arrowGroup = []
            let line = document.createElement('div');
            line.className = 'ui-inventory-line';

            arrows.forEach((arrow) => {
                if (arrow.id > this.MAX_TYPE) this.MAX_TYPE = arrow.id;
                arrowGroup.push(arrow.id);
                this.moddedArrows[arrow.id] = arrow;
                mod.arrows[arrow.id] = arrow;
                arrow.mod = mod;
                let item = document.createElement('div');
                item.className = 'inventory-item';
                let index = arrow.id;
                item.onclick = () => { game.navigation.gamePage.playerUI.toolbarController.inventory.selectCallback(index) }
                let img = document.createElement('img');
                img.src = arrow.icon_url;
                item.appendChild(img);
                line.appendChild(item);
                this.AtlasModifier.appendArrow(index, arrow.icon_url);
            });
            game.navigation.gamePage.playerUI.toolbarController.inventory.itemsBlock.appendChild(line);
            game.navigation.gamePage.playerUI.toolbarController.arrowGroups.push(arrowGroup);
        }
        closeAnyModal = function() {
            return false;
        }
    }

    while (true) {
        let x;
        try {
            x = window.game.navigation.gamePage.game.gameMap.chunks;
            break;
        } catch (e) {
            await new Promise(resolve => setTimeout(resolve, 10));
        }
    }
    console.log('FAPI Loaded');
    window.game.FAPI = new FAPI();
})();


(() => {
    console.log('API loading...');

    window.game.FAPI = {}
    window.game.FAPI.signalUpdating = {} // Используется для обработки сигналов во время тика

    // regionClasses
    class Mod {
        constructor() {
            this.id = 0;
            this.name = '';
            this.author = '';
            this.description = '';
            this.arrows = {};
        }
    }
    class ModArrow {
        constructor() {
            this.name = [];
            this.info = [];
            this.does = [];
            this.icon_url = "";
            this.is_pressable = false;
            this.custom_data = 0;
            this.id = 25;
            this.update = (arrow) => arrow.signal = 0;
            this.press = (arrow) => undefined;
            this.transmit = (arrow) => undefined;
        }
    }

    window.game.FAPI.Mod = Mod;
    window.game.FAPI.ModArrow = ModArrow;
    // endregion
    // regionSignalUpdating
    window.game.FAPI.signalUpdating.toLast = function(arrow) {
        arrow.lastType = arrow.type;
        arrow.lastSignal = arrow.signal;
        arrow.lastRotation = arrow.rotation;
        arrow.lastFlipped = arrow.flipped;
    }
    window.game.FAPI.signalUpdating.updateCount = function(arrow) {
        if (arrow !== undefined) arrow.signalsCount += 1;
    }
    /**
     * Блокирует сигнал стрелочки
     * @param {Object.<string,any> | void} arrow Стрелочка сигнал которой нужно заблокировать
     */
    window.game.FAPI.signalUpdating.blockSignal = function(arrow) {
        if (arrow !== undefined) arrow.signal = 0;
    }
    /**
     * @param {Object.<string,any>} chunk - Чанк
     * @param {number} x - Позиция по X
     * @param {number} y - Позиция по Y
     * @param {number} rotation - Поворот стрелочки ( 0 вверх | 1 вправо | 2 вниз | 3 влево )
     * @param {boolean} flipped - Зеркально расположена или нет
     * @param {number} distance - Дистанция от стрелочки ( отрицательное = вперёд | положительное = назад )
     * @param {number} diagonal - Дистанция от стрелочки в сторону ( отрицательное = вправо | положительное = влево )
     * @return {Object.<string,any> | void} - Возвращает стрелочку если находит её, а иначе `null`
     */
    window.game.FAPI.signalUpdating.adv_getArrowAt = function(chunk, x, y, rotation, flipped, distance=-1, diagonal=0) {
        if (flipped) diagonal = -diagonal;

        if (rotation === 0) {
            y += distance;
            x += diagonal;
        }
        else if (rotation === 1) {
            y += diagonal;
            x -= distance;
        }
        else if (rotation === 2) {
            y -= distance;
            x -= diagonal;
        }
        else if (rotation === 3) {
            y -= diagonal;
            x += distance;
        }

        let l = chunk;
        if (x >= window.API.main.CHUNK_SIZE) {
            if (y >= window.API.main.CHUNK_SIZE) {
                l = chunk.adjacentChunks[3];
                x -= window.API.main.CHUNK_SIZE;
                y -= window.API.main.CHUNK_SIZE;
            }
            else if (y < 0) {
                l = chunk.adjacentChunks[1];
                x -= window.API.main.CHUNK_SIZE;
                y += window.API.main.CHUNK_SIZE;
            }
            else {
                l = chunk.adjacentChunks[2];
                x -= window.API.main.CHUNK_SIZE;
            }
        }
        else if (x < 0) {
            if (y < 0) {
                l = chunk.adjacentChunks[7];
                x += window.API.main.CHUNK_SIZE;
                y += window.API.main.CHUNK_SIZE;
            } else if (y >= window.API.main.CHUNK_SIZE) {
                l = chunk.adjacentChunks[5];
                x += window.API.main.CHUNK_SIZE;
                y -= window.API.main.CHUNK_SIZE;
            } else {
                l = chunk.adjacentChunks[6];
                x += window.API.main.CHUNK_SIZE;
            }
        }
        else if (y < 0) {
            l = chunk.adjacentChunks[0];
            y += window.API.main.CHUNK_SIZE;
        }
        else if (y >= window.API.main.CHUNK_SIZE) {
            l = chunk.adjacentChunks[4];
            y -= window.API.main.CHUNK_SIZE;
        }

        if (l !== undefined) return l.getArrow(x, y);
    }
    function _updateSignals(gameMap) {
        gameMap.chunks.forEach((chunk) => {
            for (let x = 0; x < window.API.main.CHUNK_SIZE; x++) {
                for (let y = 0; y < window.API.main.CHUNK_SIZE; y++) {
                    const arrow = chunk.getArrow(x, y);
                    _tolast(arrow);
                    switch (arrow.type) {
                        case 0:
                            break;
                        case 1: // Стрелочка
                        case 4: // Стрелочка задержки
                        case 5: // Передатчик
                        case 22: // Стрелочка из уровня #1
                            if (arrow.signal === 1) _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped));
                            break;
                        case 2: // Источник
                        case 9: // Тактовый источник
                            if (arrow.signal === 1) {
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, -1));
                            }
                            break;
                        case 6: // <>
                            if (arrow.signal === 1) {
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 1, 0));
                            }
                            break;
                        case 7: // ^>
                            if (arrow.signal === 1) {
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                            }
                            break;
                        case 8: // <^>
                            if (arrow.signal === 1) {
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, -1));
                            }
                            break;
                        case 10: // Синяя стрелочка
                            if (arrow.signal === 2) _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -2))
                            break;
                        case 11: // Диагональная стрелочка
                            if (arrow.signal === 2) _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 1))
                            break;
                        case 12: // Синий курсор
                            if (arrow.signal === 2) {
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -2, 0));
                            }
                            break;
                        case 13: // Полусиний курсор
                            if (arrow.signal === 2) {
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -2, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                            }
                            break;
                        case 14: // Синий курсор ЛКМ
                            if (arrow.signal === 2) {
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 1));
                            }
                            break;
                        case 15: // НЕ
                        case 16: // И
                        case 17: // Хуйня какая та
                        case 18: // Ячейка памяти
                        case 19: // И + Ячейка памяти
                            if (arrow.signal === 3) _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped))
                            break;
                        case 20: // Рандомизатор
                        case 24: // Направленная кнопка
                            if (arrow.signal === 5) _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped));
                            break;
                        case 21: // Кнопка
                            if (arrow.signal === 5) {
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, -1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, 1));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 1, 0));
                                _updateCount(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 0, -1));
                            }
                            break;
                        default:
                            let marrow = window.API.main.arrows[arrow.type];
                            if (marrow !== undefined) marrow.transmit(arrow, chunk, x, y);
                            break;
                    }
                }
            }
        });
        gameMap.chunks.forEach((chunk) => {
            for (let x = 0; x < window.API.main.CHUNK_SIZE; x++) {
                for (let y = 0; y < window.API.main.CHUNK_SIZE; y++) {
                    const arrow = chunk.getArrow(x, y);
                    switch (arrow.type) {
                        case 0:
                            break;
                        case 1:
                        case 3:
                        case 6:
                        case 7:
                        case 8:
                        case 23:
                            arrow.signal = arrow.signalsCount > 0 ? 1 : 0;
                            break;
                        case 2:
                            arrow.signal = 1;
                            break;
                        case 4:
                            if (arrow.signal === 2) arrow.signal = 1;
                            else if (arrow.signal === 0 && arrow.signalsCount > 0) arrow.signal = 2;
                            else if (arrow.signal === 1 && arrow.signalsCount > 0) arrow.signal = 1;
                            else arrow.signal = 0;
                            break;
                        case 5:
                            arrow.signal = 0;
                            const backward_arrow = _getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped, 1);
                            if (backward_arrow !== undefined) arrow.signal = backward_arrow.lastSignal !== 0 ? 1 : 0;
                            break;
                        case 9:
                            if (arrow.signal === 0) arrow.signal = 1;
                            else if (arrow.signal === 1) arrow.signal = 2;
                            break;
                        case 10:
                        case 11:
                        case 12:
                        case 13:
                        case 14:
                            arrow.signal = arrow.signalsCount > 0 ? 2 : 0;
                            break;
                        case 15:
                            arrow.signal = arrow.signalsCount > 0 ? 0 : 3;
                            break;
                        case 16:
                            arrow.signal = arrow.signalsCount > 1 ? 3 : 0;
                            break;
                        case 17:
                            arrow.signal = arrow.signalsCount % 2 === 1 ? 3 : 0;
                            break;
                        case 18:
                            if (arrow.signalsCount > 1) arrow.signal = 3;
                            else if (arrow.signalsCount === 1) arrow.signal = 0;
                            break;
                        case 19:
                            if (arrow.signalsCount > 0) arrow.signal = arrow.signal === 3 ? 0 : 3;
                            break;
                        case 20:
                            arrow.signal = (arrow.signalsCount > 0 && Math.random() < 0.5) ? 5 : 0;
                            break;
                        case 21:
                            arrow.signal = 0;
                            break;
                        case 22:
                            arrow.signal = arrow.signalsCount > 0 ? 1 : 0;
                            const n = chunk.getLevelArrow(x, y);
                            if (n !== null) n.update();
                            break;
                        case 24:
                            arrow.signal = arrow.signalsCount > 0 ? 5 : 0;
                            break;
                        default:
                            let marrow = window.API.main.arrows[arrow.type];
                            if (marrow !== undefined) marrow.update(arrow)
                            break;
                    }
                    arrow.signalsCount = 0;
                }
            }
        });
        gameMap.chunks.forEach((chunk) => {
            for (let x = 0; x < window.API.main.CHUNK_SIZE; x++) {
                for (let y = 0; y < window.API.main.CHUNK_SIZE; y++) {
                    const arrow = chunk.getArrow(x, y);
                    if (arrow.type === 3 && arrow.lastSignal === 1)
                        _removeSignal(_getArrowAt(chunk, x, y, arrow.rotation, arrow.flipped));
                }
            }
        });
        gameMap.chunks.forEach((chunk) => {
            for (let x = 0; x < window.API.main.CHUNK_SIZE; x++) {
                for (let y = 0; y < window.API.main.CHUNK_SIZE; y++) {
                    const arrow = chunk.getArrow(x, y);
                    if (arrow.type === 23) chunk.update();
                }
            }
        });
    }
    async function override_update() {
        let x = null;
        while (true) {
            try {
                x = game.ChunkUpdates;
                break;
            } catch (e) {
                await new Promise(resolve => setTimeout(resolve, 10));
            }
        }
        game.ChunkUpdates.update = _updateSignals;
    }
    override_update();
    // endregion
    // regionItemSetImage
    async function override_setImage() {
        let x = null;
        while (true) {
            try {
                x = window.game.navigation.gamePage.playerUI.toolbarController.uiToolbar.items[0];
                break;
            } catch (e) {
                await new Promise(resolve => setTimeout(resolve, 10));
            }
        }
        game.navigation.gamePage.playerUI.toolbarController.uiToolbar.items[0].__proto__.setImage = function(id) {
            if (id < 24) this.image.src = `res/sprites/arrow${id + 1}.png?v=${game.PlayerSettings.version}`;
            else {
                let marrow = window.API.main.arrows[id+1];
                if (marrow !== undefined) this.image.src = marrow.icon_url;
            }
        }
    }
    override_setImage();
    // endregion
    // regionToggleMenu
    async function override_toggleMenu() {
        let x = null;
        while (true) {
            try {
                x = game.navigation.gamePage.playerControls.playerUI.toggleMenu;
                break;
            } catch (e) {
                await new Promise(resolve => setTimeout(resolve, 10));
            }
        }
        game.navigation.gamePage.playerControls.playerUI.prevtoggleMenu = game.navigation.gamePage.playerControls.playerUI.toggleMenu;
        game.navigation.gamePage.playerControls.playerUI.toggleMenu = function(e) {
            if (window.API.closeAnyModal()) return;
            game.navigation.gamePage.playerControls.playerUI.prevtoggleMenu(e);
        }
        game.navigation.gamePage.playerControls.playerUI.isMenuOpen = function(e) {
            return null !== this.menu && !this.menu.getIsRemoved() || window.API.openedAnyModal();
        }
    }
    override_toggleMenu();

    // endregion
    // regionOverrideControls
    async function override_controls() {
        let x = null;
        while (true) {
            try {
                x = game.navigation.gamePage.playerControls.mouseHandler.leftClickCallback;
                break;
            } catch (e) {
                await new Promise(resolve => setTimeout(resolve, 10));
            }
        }
        game.navigation.gamePage.playerControls.leftClickCallback = function() {
            if (game.navigation.gamePage.playerControls.playerUI.isMenuOpen()) return;

            const nthis = game.navigation.gamePage.playerControls;
            const arrow = nthis.getArrowByMousePosition();
            const shiftPressed = nthis.keyboardHandler.getShiftPressed();

            if (arrow !== undefined && nthis.freeCursor && !shiftPressed) {
                if (arrow.type === 21 || arrow.type === 24) {
                    arrow.signal = (arrow.signal === 0 || nthis.game.playing) ? 5 : 0;
                    nthis.game.screenUpdated = true;
                } else if (arrow.type > 24) {
                    let marrow = window.API.main.arrows[arrow.type];
                    if (marrow !== undefined) marrow.press(arrow);
                }
            }
        }
        game.navigation.gamePage.playerControls.mouseHandler.leftClickCallback = game.navigation.gamePage.playerControls.leftClickCallback;
        let prevControls = game.navigation.gamePage.playerControls.update;
        game.navigation.gamePage.playerControls.update = function() {
            prevControls();

            const e = this.mouseHandler.getMousePosition();
            const t = e[0] * window.devicePixelRatio / this.game.scale - this.game.offset[0] / window.API.main.CELL_SIZE;
            const s = e[1] * window.devicePixelRatio / this.game.scale - this.game.offset[1] / window.API.main.CELL_SIZE;
            const i = ~~t - (t < 0 ? 1 : 0);
            const n = ~~s - (s < 0 ? 1 : 0);
            const arrow = this.game.gameMap.getArrow(i, n);
            if (arrow !== undefined) {
                if (arrow.type > 24) {
                    let marrow = window.API.main.arrows[arrow.type];
                    if (marrow !== undefined) document.body.style.cursor = marrow.is_pressable ? 'pointer' : 'default';
                }
            }
        }
    }
    override_controls();
    // endregion
    // regionUtilities
    function createModal() {
        let modal = document.createElement('dialog');
        modal.classList.add('ui-mod-modal');
        window.API.main.modals.push(modal);
        return modal;
    }

    function openedAnyModal() {
        let opened = false;
        window.API.main.modals.forEach((modal) => {
            if (modal !== undefined) opened = opened || modal.open;
        })
        return opened;
    }

    function closeAnyModal() {
        let closed = false;
        window.API.main.modals.forEach((modal) => {
            if (modal !== undefined && modal.open) {
                modal.close();
                closed = true;
            }
        });
        return closed;
    }

    function createInput(modal, sname, min=1, max=10) {
        let pair = document.createElement('div');
        pair.classList.add('ui-mod-pair');
        modal.appendChild(pair);
        let name = document.createElement('div');
        name.classList.add('ui-mod-name');
        name.textContent = sname;
        pair.appendChild(name);
        let input = document.createElement('input');
        input.type = 'number'
        input.placeholder = `От ${min} до ${max} ( Включительно )`
        input.min = min;
        input.max = max;
        input.classList.add('ui-mod-input');
        pair.appendChild(input);
        return input;
    }


    function createSelect(modal, sname) {
        let pair = document.createElement('div');
        pair.classList.add('ui-mod-pair');
        modal.appendChild(pair);
        let name = document.createElement('div');
        name.classList.add('ui-mod-name');
        name.textContent = sname;
        pair.appendChild(name);
        let select = document.createElement('select');
        select.classList.add('ui-mod-select');
        pair.appendChild(select);
        return select;
    }


    function createOption(select) {
        let option = document.createElement('option');
        option.classList.add('ui-mod-option');
        select.appendChild(option)
        return option;
    }


    let add_icons = []
    let atlas_modifying = false


    function tryModifyAtlas() {
        function repeat() {
            if (add_icons.length === 0) {
                game.PlayerSettings.arrowAtlasImage.onload = () => game.navigation.gamePage.game.render.createArrowTexture(game.PlayerSettings.arrowAtlasImage);
                atlas_modifying = false;
                return;
            }
            n = add_icons.pop(0);
            nindex = n[0];
            nsrc = n[1];

            let x = (nindex - 1) % 8;
            let y = ~~(nindex / 8);
            const img1 = new Image();
            const img2 = new Image();
            img1.src = game.PlayerSettings.arrowAtlasImage.src;
            img2.src = nsrc;
            img2.onload = function() {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');

                canvas.width = img1.width;
                canvas.height = img1.height;

                ctx.drawImage(img1, 0, 0);
                ctx.drawImage(img2, x * 256, y * 256);

                game.PlayerSettings.arrowAtlasImage = new Image;
                game.PlayerSettings.arrowAtlasImage.src = canvas.toDataURL('image/png');
                repeat()
            };
        }
        atlas_modifying = true;
        repeat();
    }


    function registerMod(name, author, description, on_registered) {
        let mod = new Mod();
        mod.id = window.API.main.mods.length;
        mod.name = name;
        mod.author = author;
        mod.description = description;
        window.API.main.mods.push(mod);
        console.log(`Mod ${name} registered`)
        on_registered(mod);
    }
    function registerArrows(arrows, imod) {
        let arrowGroup = []
        let line = document.createElement('div');
        line.className = 'ui-inventory-line';
        let mod = window.API.main.mods[imod]

        arrows.forEach((arrow) => {
            if (arrow.id > window.API.main.MAX_TYPE) window.API.main.MAX_TYPE = arrow.id;
            arrowGroup.push(arrow.id);
            window.API.main.arrows[arrow.id] = arrow;
            mod.arrows[arrow.id] = arrow;
            arrow.mod = mod;
            let item = document.createElement('div');
            item.className = 'inventory-item';
            let index = arrow.id;
            item.onclick = () => { game.navigation.gamePage.playerUI.toolbarController.inventory.selectCallback(index) }
            let img = document.createElement('img');
            img.src = arrow.icon_url;
            item.appendChild(img);
            line.appendChild(item);

            add_icons.push([index, arrow.icon_url]);
            console.log(`Arrow with id \`${arrow.id}\` registered`)
            if (!atlas_modifying) {
                console.log('Atlas is being to be modified')
                tryModifyAtlas();
            }
        });
        game.navigation.gamePage.playerUI.toolbarController.inventory.itemsBlock.appendChild(line);
        game.navigation.gamePage.playerUI.toolbarController.arrowGroups.push(arrowGroup);
    }

    window.API = {}
    window.API.main = {}
    window.API.main.mods = [];
    window.API.main.arrows = []
    window.API.main.modals = []
    window.API.main.CHUNK_SIZE = 16;
    window.API.main.CELL_SIZE = 256;
    window.API.main.MAX_TYPE = 24;
    window.game.API.ModArrow = ModArrow;
    window.game.API._tolast = _tolast;
    window.game.API._updateCount = _updateCount;
    window.game.API._removeSignal = _removeSignal;
    window.game.API._getArrowAt = _getArrowAt;
    window.game.API.createModal = createModal;
    window.game.API.openedAnyModal = openedAnyModal;
    window.game.API.closeAnyModal = closeAnyModal;
    window.game.API.createInput = createInput;
    window.game.API.createSelect = createSelect;
    window.game.API.createOption = createOption;
    window.game.API.registerMod = registerMod;
    window.game.API.registerArrows = registerArrows;
    // endregion

    window.API.img_sources = JSON.parse(sessionStorage.api_sources);

    console.log('API loaded successfully!');
});